import csv
from PIL import Image
w = 250
h = 250

'this was just for fun and is not a wel written script, dont use it in anything else

size = w , h
img = Image.open(r'C:\location\image.jpg')
img2 = img.resize(size, resample=0)
WIDTH, HEIGHT = img2.size

data = list(img2.getdata()) 


dList = []
for r in range(0,w):
    for c in range(0,h):    
        dd = r*(w) + c 
        dList.append([r+1,c+1,[ d for d in data[dd]] ])


with open('C:\\location\\outy.csv', 'w', newline = "") as f:
    writer = csv.writer(f)
    for s in dList:
        writer.writerows([s])
